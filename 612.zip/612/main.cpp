#include <windows.h>
#include <dbt.h>
#include <shlobj.h>
#include <iostream>
#include <string>
#include <vector>

// Define constants
#define WM_TRAYICON (WM_USER + 100)
#define IDI_TRAY 1001
#define ID_M_EXIT 2001
#define ID_M_MENU 2002

#define ID_BTN_TOGGLE 3001
#define ID_BTN_SAVE   3002
#define ID_ED_PASSWORD 3003
#define ID_ED_LOG     3004
#define ID_ED_PATH    3005
#define ID_RAD_DOCS   3006
#define ID_RAD_ALL    3007

// Global variables
NOTIFYICONDATA nid;
HWND hMainWnd = NULL;
HWND hMenuWnd = NULL;
bool isMonitoring = true;
std::string targetDir = "C:\\USB_Backup\\"; // Current applied backup directory
bool copyAllFiles = false;                 // false = docx/pptx, true = all files

// Function declarations
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK MenuProc(HWND, UINT, WPARAM, LPARAM);
void InitTray(HWND hwnd);
void ShowMenuWindow(HWND hwndParent);
void ScanAndCopy(char driveLetter);
void AddLog(std::string text);
bool MakeSureDirectoryPathExists(std::string path);

// Helper for password verification
std::string inputPassword = "";
LRESULT CALLBACK PassProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    static HWND hEdit;
    switch(msg) {
        case WM_CREATE:
            CreateWindow("STATIC", "Enter Administrator Password:", WS_CHILD | WS_VISIBLE, 20, 15, 220, 20, hwnd, NULL, NULL, NULL);
            hEdit = CreateWindow("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_PASSWORD, 20, 40, 200, 20, hwnd, (HMENU)ID_ED_PASSWORD, NULL, NULL);
            CreateWindow("BUTTON", "OK", WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON, 80, 75, 80, 25, hwnd, (HMENU)IDOK, NULL, NULL);
            break;
        case WM_COMMAND:
            if(LOWORD(wp) == IDOK) {
                char buf[32];
                GetWindowText(hEdit, buf, 32);
                inputPassword = buf;
                DestroyWindow(hwnd);
            }
            break;
        case WM_CLOSE:
            inputPassword = "";
            DestroyWindow(hwnd);
            break;
        default: return DefWindowProc(hwnd, msg, wp, lp);
    }
    return 0;
}

bool CheckPassword(HWND parent) {
    inputPassword = "";
    if (parent) EnableWindow(parent, FALSE);

    HWND hPassWnd = CreateWindowEx(WS_EX_DLGMODALFRAME, "PassWndClass", "Authentication", WS_POPUP | WS_CAPTION | WS_SYSMENU, 
        (GetSystemMetrics(SM_CXSCREEN)-260)/2, (GetSystemMetrics(SM_CYSCREEN)-150)/2, 260, 150, parent, NULL, NULL, NULL);
    
    ShowWindow(hPassWnd, SW_SHOW);
    UpdateWindow(hPassWnd);

    MSG msg;
    while (IsWindow(hPassWnd)) {
        if (GetMessage(&msg, NULL, 0, 0)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    if (parent) {
        EnableWindow(parent, TRUE);
        SetActiveWindow(parent);
        SetForegroundWindow(parent);
    }
    
    if(inputPassword == "123456") return true;
    if(!inputPassword.empty()) MessageBox(parent, "Incorrect Password!", "Error", MB_ICONERROR | MB_TOPMOST);
    return false;
}

// Main Function
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASS wc = {0};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = "USBDetectorMain";
    RegisterClass(&wc);

    WNDCLASS pwc = {0};
    pwc.lpfnWndProc = PassProc;
    pwc.hInstance = hInstance;
    pwc.hbrBackground = (HBRUSH)(COLOR_BTNFACE+1);
    pwc.lpszClassName = "PassWndClass";
    RegisterClass(&pwc);

    WNDCLASS mwc = {0};
    mwc.lpfnWndProc = MenuProc;
    mwc.hInstance = hInstance;
    mwc.hbrBackground = (HBRUSH)(COLOR_BTNFACE+1);
    mwc.lpszClassName = "USBDetectorMenu";
    RegisterClass(&mwc);

    hMainWnd = CreateWindow("USBDetectorMain", "USB Background Monitor", 0, 0, 0, 0, 0, HWND_MESSAGE, NULL, hInstance, NULL);

    MakeSureDirectoryPathExists(targetDir);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return msg.wParam;
}

// Main Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_CREATE:
            InitTray(hwnd);
            AddLog("System Started: Monitoring removable drives...");
            break;
        case WM_TRAYICON:
            if (lp == WM_RBUTTONUP) { 
                POINT pt;
                GetCursorPos(&pt);
                HMENU hMenu = CreatePopupMenu();
                AppendMenu(hMenu, MF_STRING, ID_M_MENU, "Control Panel");
                AppendMenu(hMenu, MF_STRING, ID_M_EXIT, "Exit Program");
                SetForegroundWindow(hwnd);
                int cmd = TrackPopupMenu(hMenu, TPM_RETURNCMD | TPM_NONOTIFY, pt.x, pt.y, 0, hwnd, NULL);
                DestroyMenu(hMenu);

                if (cmd == ID_M_EXIT) {
                    if (CheckPassword(hwnd)) {
                        Shell_NotifyIcon(NIM_DELETE, &nid);
                        PostQuitMessage(0);
                    }
                } else if (cmd == ID_M_MENU) {
                    if (CheckPassword(hwnd)) {
                        ShowMenuWindow(hwnd);
                    }
                }
            }
            break;
        case WM_DEVICECHANGE:
            if (wp == DBT_DEVICEARRIVAL && isMonitoring) { 
                PDEV_BROADCAST_HDR pHdr = (PDEV_BROADCAST_HDR)lp;
                if (pHdr->dbch_devicetype == DBT_DEVTYP_VOLUME) {
                    PDEV_BROADCAST_VOLUME pVol = (PDEV_BROADCAST_VOLUME)pHdr;
                    DWORD unitmask = pVol->dbcv_unitmask;
                    char driveLetter = 'A';
                    for (; unitmask; unitmask >>= 1, driveLetter++) {
                        if (unitmask & 1) break;
                    }
                    AddLog("New removable drive detected: " + std::string(1, driveLetter) + ":");
                    ScanAndCopy(driveLetter);
                }
            }
            break;
        case WM_DESTROY:
            Shell_NotifyIcon(NIM_DELETE, &nid);
            PostQuitMessage(0);
            break;
        default:
            return DefWindowProc(hwnd, msg, wp, lp);
    }
    return 0;
}

// Initialize System Tray
void InitTray(HWND hwnd) {
    nid.cbSize = sizeof(NOTIFYICONDATA);
    nid.hWnd = hwnd;
    nid.uID = IDI_TRAY;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_TRAYICON;
    nid.hIcon = LoadIcon(NULL, IDI_APPLICATION); 
    strcpy(nid.szTip, "USB Detector Tool By123");
    Shell_NotifyIcon(NIM_ADD, &nid);
}

// Show UI Menu Window
HWND hLogEdit, hStatusStatic, hToggleBtn, hPathEdit, hSaveBtn;
HWND hRadDocs, hRadAll;

void ShowMenuWindow(HWND hwndParent) {
    if (hMenuWnd != NULL && IsWindow(hMenuWnd)) {
        ShowWindow(hMenuWnd, SW_SHOWNORMAL);
        SetForegroundWindow(hMenuWnd);
        return;
    }

    hMenuWnd = CreateWindow("USBDetectorMenu", "Control Panel - By Carlos", 
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        (GetSystemMetrics(SM_CXSCREEN)-520)/2, (GetSystemMetrics(SM_CYSCREEN)-460)/2, 
        520, 460, NULL, NULL, NULL, NULL);

    // 1. Status display
    hStatusStatic = CreateWindow("STATIC", isMonitoring ? "Status: Monitoring..." : "Status: Stopped", 
        WS_CHILD | WS_VISIBLE, 20, 20, 250, 20, hMenuWnd, NULL, NULL, NULL);

    // Toggle Button
    hToggleBtn = CreateWindow("BUTTON", isMonitoring ? "Stop Monitor" : "Start Monitor", 
        WS_CHILD | WS_VISIBLE, 370, 15, 110, 30, hMenuWnd, (HMENU)ID_BTN_TOGGLE, NULL, NULL);

    // 2. Custom Target Path Input & Save Button
    CreateWindow("STATIC", "Target Backup Path:", WS_CHILD | WS_VISIBLE, 20, 60, 150, 20, hMenuWnd, NULL, NULL, NULL);
    hPathEdit = CreateWindow("EDIT", targetDir.c_str(), WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 160, 58, 230, 22, hMenuWnd, (HMENU)ID_ED_PATH, NULL, NULL);
    
    // [ADDED] Physical Save Button next to the path input box
    hSaveBtn = CreateWindow("BUTTON", "Save", WS_CHILD | WS_VISIBLE, 400, 56, 80, 25, hMenuWnd, (HMENU)ID_BTN_SAVE, NULL, NULL);

    // 3. File Type Selector (Radio Buttons)
    CreateWindow("STATIC", "File Type Mode:", WS_CHILD | WS_VISIBLE, 20, 95, 120, 20, hMenuWnd, NULL, NULL, NULL);
    
    hRadDocs = CreateWindow("BUTTON", "pptx & docx files", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP, 160, 93, 140, 20, hMenuWnd, (HMENU)ID_RAD_DOCS, NULL, NULL);
    hRadAll  = CreateWindow("BUTTON", "All files (*.*)", WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON, 310, 93, 140, 20, hMenuWnd, (HMENU)ID_RAD_ALL, NULL, NULL);
    
    // Check default radio option
    SendMessage(copyAllFiles ? hRadAll : hRadDocs, BM_SETCHECK, BST_CHECKED, 0);

    // 4. Log Box
    CreateWindow("STATIC", "Operation Log:", WS_CHILD | WS_VISIBLE, 20, 130, 200, 20, hMenuWnd, NULL, NULL, NULL);
    hLogEdit = CreateWindow("EDIT", "", 
        WS_CHILD | WS_VISIBLE | WS_BORDER | WS_VSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | ES_READONLY, 20, 155, 460, 220, hMenuWnd, (HMENU)ID_ED_LOG, NULL, NULL);

    // Author Credits
    CreateWindow("STATIC", "Author: By Carlos", WS_CHILD | WS_VISIBLE | SS_RIGHT, 360, 385, 120, 20, hMenuWnd, NULL, NULL, NULL);

    // Refresh log box text
    AddLog(""); 

    ShowWindow(hMenuWnd, SW_SHOW);
    UpdateWindow(hMenuWnd);
}

// Logger Function
std::string globalLogs = ""; 
void AddLog(std::string text) {
    if(!text.empty()) {
        SYSTEMTIME st;
        GetLocalTime(&st);
        char timeBuf[30];
        sprintf(timeBuf, "[%02d:%02d:%02d] ", st.wHour, st.wMinute, st.wSecond);
        globalLogs += std::string(timeBuf) + text + "\r\n";
    }
    if (hMenuWnd && IsWindow(hMenuWnd)) {
        SetWindowText(hLogEdit, globalLogs.c_str());
        SendMessage(hLogEdit, EM_SETSEL, 0, -1);
        SendMessage(hLogEdit, EM_SETSEL, -1, -1);
        SendMessage(hLogEdit, EM_SCROLLCARET, 0, 0);
    }
}

// Helper to create directory recursively (C++98 Standard Compatible)
bool MakeSureDirectoryPathExists(std::string path) {
    if (path.empty()) return false;
    if (path[path.length() - 1] != '\\') path += '\\';

    size_t pos = 0;
    while ((pos = path.find("\\", pos)) != std::string::npos) {
        std::string subPath = path.substr(0, pos);
        if (!subPath.empty() && subPath[subPath.length() - 1] != ':') {
            CreateDirectory(subPath.c_str(), NULL);
        }
        pos++;
    }
    return true;
}

// Menu Window Procedure
LRESULT CALLBACK MenuProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
        case WM_COMMAND:
            // Handle Toggle Monitor Button
            if (LOWORD(wp) == ID_BTN_TOGGLE) {
                isMonitoring = !isMonitoring;
                if (isMonitoring) {
                    SetWindowText(hStatusStatic, "Status: Monitoring...");
                    SetWindowText(hToggleBtn, "Stop Monitor");
                    AddLog("User Action: Enabled monitoring service.");
                } else {
                    SetWindowText(hStatusStatic, "Status: Stopped");
                    SetWindowText(hToggleBtn, "Start Monitor");
                    AddLog("User Action: Paused monitoring service.");
                }
            }
            // [CHANGED] Handle Save Button Click explicitly to apply path changes
            if (LOWORD(wp) == ID_BTN_SAVE) {
                char buf[MAX_PATH];
                GetWindowText(hPathEdit, buf, MAX_PATH);
                std::string tempPath = buf;
                
                if (!tempPath.empty()) {
                    if (tempPath[tempPath.length() - 1] != '\\') {
                        tempPath += "\\";
                    }
                    targetDir = tempPath;
                    AddLog("Settings Saved: Target path updated to: " + targetDir);
                    MessageBox(hwnd, "Backup path updated successfully!", "Success", MB_ICONINFORMATION);
                } else {
                    MessageBox(hwnd, "Path cannot be empty!", "Warning", MB_ICONWARNING);
                }
            }
            // Handle Radio Buttons
            if (LOWORD(wp) == ID_RAD_DOCS) {
                copyAllFiles = false;
                AddLog("Mode Changed: Only copying .docx & .pptx files.");
            }
            if (LOWORD(wp) == ID_RAD_ALL) {
                copyAllFiles = true;
                AddLog("Mode Changed: Copying ALL files (*.*).");
            }
            break;
        case WM_CLOSE:
            DestroyWindow(hwnd);
            hMenuWnd = NULL;
            break;
        default:
            return DefWindowProc(hwnd, msg, wp, lp);
    }
    return 0;
}

// Recursive File Search and Copy (C++98 Compatible)
void SearchFiles(std::string path) {
    std::string searchPath = path + "\\*";
    WIN32_FIND_DATA ffd;
    HANDLE hFind = FindFirstFile(searchPath.c_str(), &ffd);

    if (hFind == INVALID_HANDLE_VALUE) return;

    do {
        std::string name = ffd.cFileName;
        if (name == "." || name == "..") continue;

        std::string fullPath = path + "\\" + name;

        if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            SearchFiles(fullPath); // Recursive scan into sub-folder
        } else {
            bool shouldCopy = false;

            if (copyAllFiles) {
                shouldCopy = true; // Mode B: All files
            } else {
                // Mode A: Specific document checking
                if (name.size() > 5) {
                    std::string ext = name.substr(name.size() - 5);
                    for (size_t i = 0; i < ext.length(); ++i) {
                        ext[i] = tolower(ext[i]);
                    }
                    if (ext == ".docx" || ext.substr(1) == ".pptx") {
                        shouldCopy = true;
                    }
                }
            }

            if (shouldCopy) {
                std::string destPath = targetDir + name;
                if (CopyFile(fullPath.c_str(), destPath.c_str(), FALSE)) {
                    AddLog("Copied: " + name);
                } else {
                    AddLog("Failed to copy: " + name + " (File locked or bad path)");
                }
            }
        }
    } while (FindNextFile(hFind, &ffd) != 0);

    FindClose(hFind);
}

void ScanAndCopy(char driveLetter) {
    // Automatically dynamic-check and create the custom directory path filled in the UI text box
    AddLog("Checking backup directory structure...");
    MakeSureDirectoryPathExists(targetDir);

    std::string rootPath = std::string(1, driveLetter) + ":";
    if (copyAllFiles) {
        AddLog("Scanning " + rootPath + " for ALL files...");
    } else {
        AddLog("Scanning " + rootPath + " for .docx and .pptx files...");
    }
    
    SearchFiles(rootPath);
    AddLog("Task completed for drive " + rootPath + " -> Exported to: " + targetDir);
}
