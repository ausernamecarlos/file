// 1. 核心防衝突巨集：必須放在最頂端
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

// 2. 網路通訊標頭檔：必須在 windows.h 之前載入
#include <winsock2.h>
#include <windows.h>

// 自動鏈結網路庫，防止 MinGW 鏈結器報錯
#pragma comment(lib, "ws2_32.lib")

#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

#define KEY_PAUSE_TOGGLE VK_OEM_1 
#define DEFAULT_PORT 10007
#define DEFAULT_SPEED 0.05
#define CHIN_LINE_SIZE 71 // 嚴格對齊 chin.h textbuffer 的二維陣列寬度

// 確保本機擁有緩衝區常數定義，防範未引入 chin.h 的報錯
#ifndef BUFFER_SIZE
#define BUFFER_SIZE 40860
#endif

bool g_isPaused = false;

// 模擬打字發送引擎 (完美支援多行自動跳行與 IME 繁體中文發送)
void SendTextToGame(HWND gameHwnd, const std::vector<std::string>& textLines, double secondsPerChar) {
    if (!gameHwnd || textLines.empty()) return;

    DWORD delayMs = static_cast<DWORD>(secondsPerChar * 1000.0);
    std::cout << "\n[System] Auto-typing sequence initialized! Toggle via [;] key.\n" << std::endl;

    for (size_t lineIdx = 0; lineIdx < textLines.size(); lineIdx++) {
        std::string text = textLines[lineIdx];
        size_t length = text.length();
        size_t i = 0;

        std::cout << "[Typing] Line " << (lineIdx + 1) << " / " << textLines.size() << "..." << std::endl;

        while (i < length) {
            if (GetAsyncKeyState(KEY_PAUSE_TOGGLE) & 0x8000) {
                g_isPaused = !g_isPaused; 
                if (g_isPaused) std::cout << "\n[Status] Auto-typing [PAUSED]. Press [;] to resume..." << std::endl;
                else std::cout << "\n[Status] Auto-typing [RESUMED]..." << std::endl;
                Sleep(300);
            }

            if (g_isPaused) {
                Sleep(50);
                continue;
            }

            BYTE currentChar = static_cast<BYTE>(text[i]);

            // 精準識別並發送 Big5 繁體中文雙位元組
            if (IsDBCSLeadByte(currentChar) && (i + 1 < length)) {
                BYTE nextChar = static_cast<BYTE>(text[i + 1]);
                WPARAM wch = (WPARAM)((currentChar << 8) | nextChar);
                SendMessageA(gameHwnd, WM_IME_CHAR, wch, 0);
                i += 2; 
            } else {
                // 常規英數字、半形標點或空白
                PostMessageA(gameHwnd, WM_CHAR, (WPARAM)currentChar, 0);
                i += 1; 
            }

            Sleep(delayMs);
        }

        // 每行打完，自動向遊戲發送換行回車 (VK_RETURN)
        PostMessageA(gameHwnd, WM_KEYDOWN, VK_RETURN, 0);
        PostMessageA(gameHwnd, WM_KEYUP, VK_RETURN, 0);
        Sleep(delayMs * 4); 
    }
}

// 核心解碼引擎：採用固定步進切片，並強化前綴與換行符過濾
std::vector<std::string> FetchAndCleanServerText(const std::string& ipAddress) {
    std::vector<std::string> cleanLines;
    
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) return cleanLines;

    SOCKET connectSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    sockaddr_in clientService;
    clientService.sin_family = AF_INET;
    clientService.sin_addr.s_addr = inet_addr(ipAddress.c_str());
    clientService.sin_port = htons(DEFAULT_PORT);

    std::cout << "[Network] Connecting to competition server at " << ipAddress << "..." << std::endl;
    if (connect(connectSocket, (SOCKADDR*)&clientService, sizeof(clientService)) == SOCKET_ERROR) {
        closesocket(connectSocket);
        WSACleanup();
        return cleanLines;
    }

    std::string request = "GETDATA:";
    send(connectSocket, request.c_str(), (int)request.length(), 0);

    // 使用大容量緩衝區
    std::vector<char> recvBuffer(BUFFER_SIZE * 2, 0); 
    int bytesReceived = recv(connectSocket, &recvBuffer[0], (int)recvBuffer.size() - 1, 0);
    
    closesocket(connectSocket);
    WSACleanup();

    if (bytesReceived <= 0) return cleanLines;

    std::string responseStr(&recvBuffer[0], bytesReceived);
    size_t headerPos = responseStr.find("GETDATA-ACK:");
    if (headerPos == std::string::npos) return cleanLines;

    // 確定核心資料流起始點
    size_t dataStartOffset = headerPos + 12;
    char* dataPtr = &recvBuffer[dataStartOffset];
    int remainingBytes = bytesReceived - (int)dataStartOffset;

    std::cout << "\n========= [Perfect Aligned Stream Dump] =========" << std::endl;

    // 強制作業系統進行「固定寬度 71 位元組跳躍」
    for (int blockOffset = 0; blockOffset + CHIN_LINE_SIZE <= remainingBytes; blockOffset += CHIN_LINE_SIZE) {
        char* currentLinePtr = dataPtr + blockOffset;
        std::string processedLine = "";

        for (int j = 0; j < CHIN_LINE_SIZE; j++) {
            char c = currentLinePtr[j];
            if (c == '\0') {
                break;
            }
            if (c == '\r' || c == '\n') {
                continue; 
            }
            processedLine += c;
        }

        // 【終極強效前綴過濾邏輯】
        // 由於記憶體對齊原因，E: 或 C: 可能出現在最前面，也可能前面帶有微小雜訊。
        // 我們直接掃描字串前驅部分，只要發現 "E:" 或 "C:" 標籤，就精準切除其及前方所有內容。
        size_t ePos = processedLine.find("E:");
        size_t cPos = processedLine.find("C:");
        
        if (ePos != std::string::npos && ePos < 5) {
            processedLine = processedLine.substr(ePos + 2);
        } else if (cPos != std::string::npos && cPos < 5) {
            processedLine = processedLine.substr(cPos + 2);
        }

        // 智慧過濾尾部的隨機記憶體殘留垃圾
        if (processedLine.empty() || processedLine == " " || processedLine.find("??") != std::string::npos) {
            break;
        }
        if ((BYTE)processedLine[0] > 0x7F && !IsDBCSLeadByte((BYTE)processedLine[0])) {
            break; 
        }

        std::cout << processedLine << std::endl;
        cleanLines.push_back(processedLine);
    }

    std::cout << "========= [Perfect Aligned Stream Finished] =========\n" << std::endl;
    return cleanLines;
}

int main() {
    SetConsoleTitleA("Ultimate Aligned Interceptor v9.0");

    HWND hwndGame = FindWindowA("cinwin", NULL);
    if (hwndGame == NULL) {
        std::cout << "[Error] Target window ('cinwin') not found!" << std::endl;
        system("pause");
        return 1;
    }

    char originalTitle[512] = {0};
    GetWindowTextA(hwndGame, originalTitle, sizeof(originalTitle) - 1);
    std::string newTitle = std::string(originalTitle) + " - Linked";
    SetWindowTextA(hwndGame, newTitle.c_str());
    std::cout << "[Success] Game window linked." << std::endl;

    std::string serverIP;
    std::cout << "Enter Competition Server IP (Press Enter for 127.0.0.1): ";
    std::getline(std::cin, serverIP);
    if (serverIP.empty()) serverIP = "127.0.0.1";

    std::vector<std::string> detectedTextLines = FetchAndCleanServerText(serverIP);

    if (detectedTextLines.empty()) {
        std::cout << "[Error] Failed to parse network stream." << std::endl;
        system("pause");
        return 1;
    }

    std::cout << "[Success] Extracted " << detectedTextLines.size() << " valid lines of text." << std::endl;

    double speed = DEFAULT_SPEED;
    std::string inputSpeedStr;
    std::cout << "Enter typing speed [Press Enter for default " << DEFAULT_SPEED << "s]: ";
    std::getline(std::cin, inputSpeedStr);
    
    if (!inputSpeedStr.empty()) {
        double parsedSpeed = atof(inputSpeedStr.c_str());
        if (parsedSpeed > 0.0) speed = parsedSpeed;
    }

    std::cout << "\n[Ready] Shift focus to the Game Input Area within 3 seconds..." << std::endl;
    for (int countdown = 3; countdown > 0; countdown--) {
        std::cout << countdown << "... " << std::flush;
        Sleep(1000);
    }
    std::cout << "Go!" << std::endl;

    SendTextToGame(hwndGame, detectedTextLines, speed);

    std::cout << "\n[Finished] All lines typed successfully with perfect alignment." << std::endl;
    system("pause");
    return 0;
}
